load.initialize("Initialize", async function () {
});

load.action("Action", async function () {
    load.log("Hello DevWeb");
});

load.finalize("Finalize", async function () {
});
