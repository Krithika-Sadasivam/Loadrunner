declare const Error: ErrorConstructor;

export = Error;
