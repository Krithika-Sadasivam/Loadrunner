declare module 'emoji-regex' {
  export default function emojiRegex(): RegExp;
}
