export declare const isByteArray: (input: any) => input is Uint8Array;
